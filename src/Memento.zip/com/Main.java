package com;

public class Main {

    public static void main(String[] args) {
//                Stack<Integer> s = new Stack<>();
//                s.push(2);s.printState();
//                s.push(4);s.printState();
//                s.push(6);s.printState();
//                s.undo();s.printState();
//                s.undo();s.printState();
//                s.redo();s.printState();
//                s.push(10);s.printState();
//                s.redo() ;s.printState();
//                s.pop();s.printState();
//                s.undo();s.printState();
//                s.redo();s.printState();

        new StackUndoRedo().setVisible(true);

    }
}
